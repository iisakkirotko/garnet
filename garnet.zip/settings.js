import Gio from "gi://Gio";
const CURSOR_FOLLOW = "cursor-follows-focus";
export class Settings {
    cursorFollowsFocus = true;
    defaultLayout = 0;
    _gio;
    constructor(gsettings) {
        this._gio = gsettings;
        this.cursorFollowsFocus = gsettings.get_boolean(CURSOR_FOLLOW);
    }
    get gio() {
        return this._gio;
    }
}

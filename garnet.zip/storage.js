export class DenseStore {
    values;
    freeIndices = [];
    constructor(initial) {
        if (initial) {
            this.values = initial;
        }
        else {
            this.values = new Array();
        }
    }
    push(val) {
        const idx = this.freeIndices.pop();
        if (idx === undefined) {
            this.values.push(val);
            return;
        }
        this.values[idx] = val;
    }
    remove(val) {
        let idx;
        let item;
        if (typeof val === "number") {
            idx = val;
            const fetched = this.values.at(idx);
            if (fetched === undefined || fetched === null) {
                throw new Error(`Tried to find element to remove in values, but it does not exist`);
            }
            item = fetched;
        }
        else {
            item = val;
            idx = this.values.indexOf(val);
        }
        if (val === -1 || item === undefined) {
            throw new Error(`Tried to find element to remove in values, but it does not exist`);
        }
        this.values[idx] = null;
        this.freeIndices.push(idx);
        return item;
    }
    at(index) {
        return this.values.at(index);
    }
    map(callbackfn) {
        const cleanValues = this.values.filter((value) => value !== null);
        return cleanValues.map(callbackfn);
    }
    find(predicate) {
        return this.values.find((value, index) => {
            if (value === null) {
                return false;
            }
            return predicate(value, index);
        });
    }
    get length() {
        const cleanValues = this.values.filter((value) => value !== null);
        return cleanValues.length;
    }
    /**
     * Iterate through the dense set
     * @returns T
     */
    [Symbol.iterator]() {
        let index = 0;
        const items = this.values.filter((value) => value !== null);
        return {
            next() {
                if (index < items.length) {
                    const item = items[index++];
                    if (item === undefined) {
                        throw new Error(`Got a undefined while iterating through dense set at index ${index}`);
                    }
                    return { value: item, done: false };
                }
                return { value: undefined, done: true };
            },
        };
    }
}
